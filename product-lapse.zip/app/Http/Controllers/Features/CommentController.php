<?php

namespace App\Http\Controllers\Features;

use App\Models\Comment;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class CommentController extends Controller
{
    public function index()
    {
        
    }
    public function store()
    {
        
    }
    public function delete(Comment $comment)
    {
        
    }
}
