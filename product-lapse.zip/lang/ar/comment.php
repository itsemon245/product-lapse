<?php 

return [
        //comments part
        'comments' => 'تعليقات',
        'write-comment' => 'اكتب تعليقا',
];