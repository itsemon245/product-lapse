<?php

return [
    'password' => 'Password',
    'password_confirmation' => 'Confirm Password',
    'create_password' => 'Create Your Password',
    'confirm' => 'Confirm',
];