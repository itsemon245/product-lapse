<?php 


return [
    'create' => 'Created Successfully!',
    'update' => 'Updated Successfully!',
    'delete' => 'Deleted Successfully!',
];