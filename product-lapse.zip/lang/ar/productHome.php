<?php 

return [
    'title' => 'المنتج',
    'choose' => 'اختر المنتجات..',
    'edit' => 'تعديل المنتج',
    'showing' => 'المنتجات',
    'innovate' => 'ابتكر',
    'product-planning' => 'خطط',
    'product-support' => 'طلبات الدعم',
    'change-management' => 'طلبات التغيير',
    'documentation' => 'وثائق المنتج',
    'product-team' => 'فريق المنتج',
    'reporting' => 'تقارير المنتج',
    'product-info' => 'معلومات المنتج',
    'product-history' => 'اصدارات المنتج',
    'historical-image' => 'صور تاريخية',
    'product-delivery' => 'تسليمات المنتج',
    'categories' => 'تسليمات المنتج',
    'certificate' => 'صنع الشهادة',

    
];