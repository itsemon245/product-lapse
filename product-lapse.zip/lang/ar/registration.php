<?php

return [
    'fisrt_name' => 'First Name',
    'last_name' => 'Last Name',
    'email' => 'Email',
    'password' => 'Password',
    'work_place' => 'Workplace',
    'phone' => 'Phone',
    'position' => 'Position',
    'sign_up' => 'Sign Up',
    'cancel' => 'Cancel',
    'promo_code' => 'Promo Code',
    'already_have_account' => 'Already have an account?',
    'login' => 'Login',
    'register_success' => 'Register Success',
    'terms' => 'Terms &amp; conditions',
];
