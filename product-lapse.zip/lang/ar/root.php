<?php 

return [
    //breadcrumb 
    'dashboard' => 'الرئيسية',
    //footer copyrights
    'footer' => [
        'copyrights' => 'حقوق النشر',
        'privacy-policy' => 'سياسة الخصوصية',
        'terms' =>'شروط الاستخدام',
        'support' => 'الدعم الفنى',
    ],


];