<?php


return [
        //comments part
        'comments' => 'Comments',
        'write-comment' => 'Write comment',
];