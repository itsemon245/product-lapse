<?php 

return [
    'title' => 'Product History',
    'button' => 'New group',
    'modal-title' => 'Add new group',
    'date' => 'Date',
    'description' => 'Description',
    'images' => 'Images',
    'modal-btn' => 'Add',
];

