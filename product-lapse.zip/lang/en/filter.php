<?php 

return [
    'all'=>'All',
    'no-items'=> 'No items to filter',
]

?>