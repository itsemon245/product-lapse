<?php


return [
    'create' => 'Failed to create!',
    'update' => 'Failed to update!',
    'delete' => 'Failed to delete!',
];