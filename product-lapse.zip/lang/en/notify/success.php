<?php 


return [
    'create' => 'Created Successfully!',
    'update' => 'Updated Successfully!',
    'delete' => 'Deleted Successfully!',
    'invitation_sent' => 'Invitation Sent   Successfully!',
];