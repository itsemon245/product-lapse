<?php 

return [
    //
    'title' => 'Product',
    'choose' => 'Choose Products..',
    'edit' => 'Edit product',
    'showing' => 'Products',
    'innovate' => 'Innovate',
    'product-planning' => 'Product Planning',
    'product-support' => 'Product Support',
    'change-management' => 'Change Management',
    'documentation' => 'Product Documentation',
    'product-team' => 'Product Team',
    'reporting' => 'Product Reporting',
    'product-info' => 'Product Info',
    'product-history' => 'Product Release',
    'historical-image' => 'Historical Images',
    'product-delivery' => 'Product Delivery',
    'categories' => 'Product Category',
    'certificate' => 'Certificate Make',

    
];