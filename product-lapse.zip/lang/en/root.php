<?php 

return [
    //breadcrumb 
    'dashboard' => 'Dashboard',
    //footer copyrights
    'footer' => [
        'copyrights' => 'copyrights',
        'privacy-policy' => 'Privacy Policy',
        'terms' =>'Terms & Conditions',
        'support' => 'Technical support',
    ],


];