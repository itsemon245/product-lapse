<a class="navbar-brand" href="{{route('home')}}">
    <img src="img/logo-white.png" class="logo1 hidden dark:block" srcset="img/logo-white.png 2x" alt="logo">
    <img src="img/logo.png" class="logo2 block dark:hiden" srcset="img/logo.png 2x" alt="logo">
</a>