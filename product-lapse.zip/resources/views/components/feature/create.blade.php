<div class="m-0 p-0">
    {{ $breadcrumb }}
    <section class="sign_in_area bg_color sec_pad">
        <div class="container">
            <div class="sign_info">
                <div class="login_info">
                    {{ $from }}
                </div>
            </div>
        </div>
    </section>
</div>
