<div class="col-md-12 row" style="height: 40vh;"   >
    <div class="col-md-4"></div>
    <div class="col-md-4"><img style="opacity: 0.8;" src="{{ asset('img/not-found.png') }}" alt=""></div>
    <div class="col-md-4"></div>
</div>