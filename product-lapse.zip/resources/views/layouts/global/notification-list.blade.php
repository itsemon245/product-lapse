<li class="nav-item dropdown submenu notifi-list">
    <a class="nav-link dropdown-toggle btn-bg btn-icon" href="#" role="button"
        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <i class="ti-bell"></i><span class="notifi-num">25</span>
    </a>
    <ul class="dropdown-menu">
        <li class="nav-item">
            <a href="blog-grid.html" class="nav-link">
                <div class="feedback_item">
                    <div class="feed_back_author">
                        <div class="media">
                            <div class="img">
                                <img src="img/profile1.png" alt="">
                            </div>
                            <div class="media-body">
                                <h5 class="f_500"><span>Ahmed Mahmoud</span> Add you to his list</h5>
                                <h6 class="f_400">25 min ago</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </li>
        <li class="nav-item">
            <a href="blog-grid.html" class="nav-link">
                <div class="feedback_item">
                    <div class="feed_back_author">
                        <div class="media">
                            <div class="img">
                                <img src="img/profile1.png" alt="">
                            </div>
                            <div class="media-body">
                                <h5 class="f_500"><span>Ahmed Mahmoud</span> Add you to his list</h5>
                                <h6 class="f_400">25 min ago</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </li>
        <li class="nav-item">
            <a href="blog-grid.html" class="nav-link">
                <div class="feedback_item">
                    <div class="feed_back_author">
                        <div class="media">
                            <div class="img">
                                <img src="img/profile1.png" alt="">
                            </div>
                            <div class="media-body">
                                <h5 class="f_500"><span>Ahmed Mahmoud</span> Add you to his list</h5>
                                <h6 class="f_400">25 min ago</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </li>
        <li class="nav-item">
            <a href="blog-grid.html" class="nav-link">
                <div class="feedback_item">
                    <div class="feed_back_author">
                        <div class="media">
                            <div class="img">
                                <img src="img/profile1.png" alt="">
                            </div>
                            <div class="media-body">
                                <h5 class="f_500"><span>Ahmed Mahmoud</span> Add you to his list</h5>
                                <h6 class="f_400">25 min ago</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </li>
        <li class="nav-item text-center"><a href="#" class="nav-link">View all</a></li>
    </ul>
</li>