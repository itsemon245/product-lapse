<div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav menu pl_120">
        <li class="nav-item">
            <a class="nav-link" href="#tolink-1">
                Home
            </a>
        </li>
        <?php if(auth()->guard()->check()): ?>
        <li class="nav-item hidden-md visible-sm">
            <a class="nav-link" href="#tolink-6">
                Notifications
                <span class="notifi-num notifi-num2">25</span>
            </a>
        </li>
        <li class="nav-item dropdown submenu hidden-md visible-sm">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                Profile
            </a>
            <?php echo $__env->make('layouts.global.profile-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </li>
        <?php endif; ?>
        <li class="nav-item">
            <a class="nav-link" href="#tolink-2">
                About us
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#tolink-3">
                Features
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#tolink-4">
                Packages
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#tolink-5">
                Faq
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#tolink-6">
                Contact us
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link" href="#">
                عربى
            </a>
        </li>
    </ul>
</div><?php /**PATH /home/parvez/Desktop/product-lapse/resources/views/layouts/frontend/navigation.blade.php ENDPATH**/ ?>