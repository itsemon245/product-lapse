<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-fileinput/5.0.8/css/fileinput.min.css">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('main'); ?>
    <?php if (isset($component)) { $__componentOriginal269900abaed345884ce342681cdc99f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal269900abaed345884ce342681cdc99f6 = $attributes; } ?>
<?php $component = App\View\Components\Breadcrumb::resolve(['list' => [['label' => @__('feature/productHistory.title'), 'route' => route('product-history.index')]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Breadcrumb::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $attributes = $__attributesOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__attributesOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $component = $__componentOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__componentOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>

        <section class="sign_in_area bg_color sec_pad">
            <div class="container">
                <div class="sign_info">
                    <div class="login_info">
                        <div class="d-flex justify-content-between align-items-center mb_20">
                            <h2 class=" f_600 f_size_24 t_color3"><?php echo __('feature/productHistory.title') ?></h2>
                            <button type="submit" class="btn_hover agency_banner_btn btn-bg" style="margin: 0"
                                data-toggle="modal" data-target="#myModal"><i class="ti-plus"></i><?php echo __('feature/productHistory.button') ?></button>
                        </div>
                        <div class="tab-content faq_content" id="myTabContent">
                            <div class="tab-pane fade show active" id="purchas" role="tabpanel" aria-labelledby="purchas-tab">
                                <div id="accordion">
                                    <div class="card">
                                        <div class="card-header" id="headingTwo">
                                            <h5 class="mb-0">
                                                <button class="btn btn-link collapsed" data-toggle="collapse"
                                                    data-target="#collapseTwo" aria-expanded="false"
                                                    aria-controls="collapseTwo">
                                                    10 January 2029<i class="ti-angle-down"></i><i class="ti-angle-up"></i>
                                                </button>
                                            </h5>
                                        </div>
                                        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo"
                                            data-parent="#accordion">
                                            <div class="card-body">
                                                <div class="row">
                                                    <div class="col-12 history-notes">
                                                    </div>
                                                    <div class="col-12">
                                                        <h6 class="title2">Description</h6>
                                                        <p class="f_400 mb-30 text-font">
                                                            It is a long established fact that a reader will be distracted by
                                                            the readable content of a page when looking at its layout It is a
                                                            long established fact that a reader will be distracted by the
                                                            readable content of a page when looking at its layout
                                                        </p>
                                                    </div>
                                                    <div class="col-xl-2 col-lg-3 col-md-4 col-6">
                                                        <div class="product-history">
                                                            <img src="img/p1.jpg">
                                                            <h6>Rolex watch</h6>
                                                            <a href="#"></a>
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-2 col-lg-3 col-md-4 col-6">
                                                        <div class="product-history">
                                                            <img src="img/p1.jpg">
                                                            <h6>Rolex watch</h6>
                                                            <a href="#"></a>
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-2 col-lg-3 col-md-4 col-6">
                                                        <div class="product-history">
                                                            <img src="img/p1.jpg">
                                                            <h6>Rolex watch</h6>
                                                            <a href="#"></a>
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-2 col-lg-3 col-md-4 col-6">
                                                        <div class="product-history">
                                                            <img src="img/p1.jpg">
                                                            <h6>Rolex watch</h6>
                                                            <a href="#"></a>
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-2 col-lg-3 col-md-4 col-6">
                                                        <div class="product-history">
                                                            <img src="img/p1.jpg">
                                                            <h6>Rolex watch</h6>
                                                            <a href="#"></a>
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-2 col-lg-3 col-md-4 col-6">
                                                        <div class="product-history">
                                                            <img src="img/p1.jpg">
                                                            <h6>Rolex watch</h6>
                                                            <a href="#"></a>
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-2 col-lg-3 col-md-4 col-6">
                                                        <div class="product-history">
                                                            <img src="img/p1.jpg">
                                                            <h6>Rolex watch</h6>
                                                            <a href="#"></a>
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-2 col-lg-3 col-md-4 col-6">
                                                        <div class="product-history">
                                                            <img src="img/p1.jpg">
                                                            <h6>Rolex watch</h6>
                                                            <a href="#"></a>
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-2 col-lg-3 col-md-4 col-6">
                                                        <div class="product-history">
                                                            <img src="img/p1.jpg">
                                                            <h6>Rolex watch</h6>
                                                            <a href="#"></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    <!-- The Modal -->
    <div class="modal fade" id="myModal">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <form method="POST" action="" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h4 class="modal-title"><?php echo __('feature/productHistory.modal-title') ?></h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>

                    <!-- Modal body -->
                    <div class="modal-body">
                        <div class="container-fluid">
                            <div class="form-group text_box col-lg-12 col-md-12">
                                <label class=" text_c f_500"><?php echo __('feature/productHistory.date') ?></label>
                                <input type="date" placeholder="date" name="date" required>
                            </div>
                            <div class="form-group text_box col-lg-12 col-md-12">
                                <label class=" text_c f_500">Description</label>
                                <textarea name="description" id="message" cols="30" rows="10" placeholder="Description" required></textarea>
                            </div>
                            <div class="form-group text_box col-lg-12 col-md-12">
                                <label class=" text_c f_500"><?php echo __('feature/productHistory.images') ?></label>
                                <div class="verify-sub-box">
                                    <div class="file-loading">
                                        <input id="multiplefileupload" name="image[]" type="file" accept=".jpg,.gif,.png"
                                            multiple />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Modal footer -->
                    <div class="modal-footer">
                        <button type="submit" class="btn_hover agency_banner_btn btn-bg agency_banner_btn2"><?php echo __('feature/productHistory.modal-btn') ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-fileinput/5.0.8/js/fileinput.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-fileinput/5.0.8/js/plugins/sortable.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-fileinput/5.0.8/themes/fas/theme.min.js"></script>
        <script>
            // ----------multiplefile-upload---------
            $("#multiplefileupload").fileinput({
                'theme': 'fa',
                'uploadUrl': '#',
                showRemove: false,
                showUpload: false,
                showZoom: false,
                showCaption: false,
                browseClass: "btn btn-danger",
                browseLabel: "",
                browseIcon: "<i class='ti ti-plus'></i>",
                overwriteInitial: false,
                initialPreviewAsData: true,
                fileActionSettings: {
                    showUpload: false,
                    showZoom: false,
                    removeIcon: "<i class='ti ti-close'></i>",
                }
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.subscriber.app', ['title' => @__('feature/productHistory.title')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/parvez/Desktop/product-lapse/resources/views/features/product/history/index.blade.php ENDPATH**/ ?>