<?php
    $id = $attributes->has('id') ? $attributes->get('id') : 'primary';
    $name = $attributes->has('name') ? $attributes->get('name') : 'primary';
    $class = $attributes->has('class') ? $attributes->get('class') : 'btn_hover agency_banner_btn btn-bg btn-bg3';
    $type = $attributes->has('type') ? $attributes->get('type') : '';

?>
<button class="<?php echo e($class . 'btn_hover agency_banner_btn btn-bg btn-bg3'); ?>" type="<?php echo e($type); ?>" id="<?php echo e($id); ?>" ><?php echo e($name); ?></button>

<?php $__env->startPush('customJs'); ?>
    <script>
        $(document).ready(function() {
            btn = $('#<?php echo e($id); ?>')
            btn.click(e => {
                history.back()
            })
        });
    </script>
<?php $__env->stopPush(); ?>



<?php /**PATH /home/parvez/Desktop/product-lapse/resources/views/components/btn-secondary.blade.php ENDPATH**/ ?>