<?php $__env->startSection('main'); ?>
<?php if (isset($component)) { $__componentOriginal3bc35c24892c0136535a2452ecbc7bd5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3bc35c24892c0136535a2452ecbc7bd5 = $attributes; } ?>
<?php $component = App\View\Components\Feature\Index::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feature.index'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Feature\Index::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('breadcrumb', null, []); ?> 
        <?php if (isset($component)) { $__componentOriginal269900abaed345884ce342681cdc99f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal269900abaed345884ce342681cdc99f6 = $attributes; } ?>
<?php $component = App\View\Components\Breadcrumb::resolve(['list' => [
            ['label' => @__('feature/certificate.title'), 'route' => route('certificate.index')],
            ]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Breadcrumb::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $attributes = $__attributesOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__attributesOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $component = $__componentOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__componentOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('search', null, []); ?> 
        <form action="#" class="search-form input-group">
            <input type="searproductch" class="form-control widget_input" placeholder="<?php echo e(__('feature/certificate.search')); ?>">
            <button type="submit"><i class="ti-search"></i></button>
        </form>
     <?php $__env->endSlot(); ?>


     <?php $__env->slot('actions', null, []); ?> 
        <?php if (isset($component)) { $__componentOriginale67687e3e4e61f963b25a6bcf3983629 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale67687e3e4e61f963b25a6bcf3983629 = $attributes; } ?>
<?php $component = App\View\Components\Button::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'link','href' => ''.e(route('certificate.create')).'']); ?> 
            <i class="ti-plus"></i>
            <?php echo __('feature/certificate.add') ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale67687e3e4e61f963b25a6bcf3983629)): ?>
<?php $attributes = $__attributesOriginale67687e3e4e61f963b25a6bcf3983629; ?>
<?php unset($__attributesOriginale67687e3e4e61f963b25a6bcf3983629); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale67687e3e4e61f963b25a6bcf3983629)): ?>
<?php $component = $__componentOriginale67687e3e4e61f963b25a6bcf3983629; ?>
<?php unset($__componentOriginale67687e3e4e61f963b25a6bcf3983629); ?>
<?php endif; ?>   
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('filter', null, []); ?> 
    
     <?php $__env->endSlot(); ?>


     <?php $__env->slot('list', null, []); ?> 
        <?php $__currentLoopData = $certificates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certificate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-6">
            <div class="item lon new">
                <div class="list_item">
                    <div class="joblisting_text">
                        <div class="job_list_table">
                            <div class="jobsearch-table-cell">
                                <h4><a href="<?php echo e(route('certificate.show', $certificate)); ?>" class="f_500 t_color3"><?php echo e($certificate->name); ?></a></h4>
                                <ul class="list-unstyled">
                                    <li><?php echo e($certificate->created_at->formatLocalized('%A %d %B %Y')); ?></li>
                                    <li><?php echo e($certificate->company); ?></li>
                                </ul>
                            </div>
                            <div class="jobsearch-table-cell">
                                <div class="jobsearch-job-userlist">
                                    <div class="like-btn">
                                        <form action="<?php echo e(route('certificate.destroy', $certificate)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <?php if (isset($component)) { $__componentOriginal660c4ad06be89181a24a71008ee12010 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal660c4ad06be89181a24a71008ee12010 = $attributes; } ?>
<?php $component = App\View\Components\BtnIcons::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('btn-icons'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\BtnIcons::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','class' => 'btn','value' => '<i class=\'ti-trash\'></i>']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal660c4ad06be89181a24a71008ee12010)): ?>
<?php $attributes = $__attributesOriginal660c4ad06be89181a24a71008ee12010; ?>
<?php unset($__attributesOriginal660c4ad06be89181a24a71008ee12010); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal660c4ad06be89181a24a71008ee12010)): ?>
<?php $component = $__componentOriginal660c4ad06be89181a24a71008ee12010; ?>
<?php unset($__componentOriginal660c4ad06be89181a24a71008ee12010); ?>
<?php endif; ?>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3bc35c24892c0136535a2452ecbc7bd5)): ?>
<?php $attributes = $__attributesOriginal3bc35c24892c0136535a2452ecbc7bd5; ?>
<?php unset($__attributesOriginal3bc35c24892c0136535a2452ecbc7bd5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3bc35c24892c0136535a2452ecbc7bd5)): ?>
<?php $component = $__componentOriginal3bc35c24892c0136535a2452ecbc7bd5; ?>
<?php unset($__componentOriginal3bc35c24892c0136535a2452ecbc7bd5); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.subscriber.app', ['title'=> @__('feature/certificate.title')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/parvez/Desktop/product-lapse/resources/views/features/certificate/index.blade.php ENDPATH**/ ?>