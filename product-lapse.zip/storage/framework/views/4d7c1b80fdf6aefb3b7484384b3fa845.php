<header class="header_area header_area_inner">
    <nav class="navbar navbar-expand-lg menu_one menu_four">
        <div class="container custom_container p0">
            <a class="navbar-brand" href="#">
                <img src="<?php echo e(asset('img/logo-white.png')); ?>" class="logo1" srcset="<?php echo e(asset('img/logo-white.png')); ?> 2x"
                    alt="logo">
                <img src="<?php echo e(asset('img/logo.png')); ?>" class="logo2" srcset="<?php echo e(asset('img/logo.png')); ?> 2x"
                    alt="logo">
            </a>
            <button class="navbar-toggler collapsed" type="button" data-toggle="collapse"
                data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="menu_toggle">
                    <span class="hamburger">
                        <span></span>
                        <span></span>
                        <span></span>
                    </span>
                    <span class="hamburger-cross">
                        <span></span>
                        <span></span>
                    </span>
                </span>
            </button>
            <?php echo $__env->make('layouts.frontend.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <ul class="navbar-nav menu hidden-sm hidden-xs navbar-nav-signin gap-4 items-center">
                <li class="nav-item dropdown submenu m-0">
                    <?php echo $__env->make('layouts.frontend.locale-switcher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </li>
                <?php if(auth()->guard()->check()): ?>

                    <li class="nav-item dropdown submenu m-0">
                        <a class="nav-link dropdown-toggle btn-bg btn-icon" href="<?php echo e(route('dashboard')); ?>" role="button"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="ti-user"></i>
                        </a>
                        <?php echo $__env->make('layouts.global.profile-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </li>
                    <?php echo $__env->make('layouts.global.notification-list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php else: ?>
                    <li class="nav-item dropdown submenu m-0">
                        <a class="btn_get btn_hover hidden-sm hidden-xs btn-bg" href="<?php echo e(route('login')); ?>">login</a>
                    <li>
                    <?php endif; ?>

            </ul>
        </div>
    </nav>
</header>
<?php /**PATH /home/parvez/Desktop/product-lapse/resources/views/layouts/frontend/header.blade.php ENDPATH**/ ?>