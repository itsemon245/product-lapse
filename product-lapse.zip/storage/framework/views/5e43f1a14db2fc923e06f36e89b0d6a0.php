<?php $__env->startSection('main'); ?>
    <?php if (isset($component)) { $__componentOriginal269900abaed345884ce342681cdc99f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal269900abaed345884ce342681cdc99f6 = $attributes; } ?>
<?php $component = App\View\Components\Breadcrumb::resolve(['list' => [['label' => @__('productHome.title'), 'route' => route('product.show', $product)]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Breadcrumb::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $attributes = $__attributesOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__attributesOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $component = $__componentOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__componentOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
    <section class="sign_in_area bg_color sec_pad" style="padding-top: 20px">
        <div class="container">
            <div class="row align-items-center mb_20">

                <div class="col-lg-12 col-md-12 products-order2">
                    <div class="shop_menu_left d-flex align-items-center justify-content-end">
                        <h5><?php echo __('productHome.title') ?></h5>
                        <form method="get" action="<?php echo e(route('product.home.filter')); ?>">
                            <select onchange="this.form.submit()" name="product_id" class="selectpickers selectpickers2">
                                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <option disabled><?php echo __('productHome.choose') ?></option>
                                <?php endif; ?>
                            </select>
                        </form>
                    </div>
                </div>
            </div>
            <div class="job_listing job_listing2 job_listing3">
                <div class="listing_tab">
                    <div class="item lon new">
                        <div class="list_item">
                            
                            <div class="joblisting_text">
                                <div class="job_list_table">
                                    <div class="jobsearch-table-cell">
                                        <h4>
                                            <a href="<?php echo e(route('product.info', productId())); ?>" class="f_500 t_color3"><?php echo e($product->name); ?></a>
                                            <a href="<?php echo e(route('product.edit', productId())); ?>" class="btn_hover agency_banner_btn btn-bg"><i
                                                class="ti-pencil"></i> <?php echo __('productHome.edit') ?></a>
                                            
                                        </h4>
                                        <ul class="list-unstyled">
                                            <li class="p_color1"><?php echo e($product->stage); ?></li>
                                            <li><?php echo e($product->description); ?></li>
                                            <li>  <a href="<?php echo e(route('product.edit', productId())); ?>" class="btn_hover agency_banner_btn btn-bg"><i
                                                class="ti-pencil"></i> <?php echo __('productHome.edit') ?></a></li>
                                        </ul>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-md-4 col-6">
                        <div class="box-item">
                            <span class="box-item-num <?php echo e($feature['counter'] == null ? 'd-none' : ''); ?>"><?php echo e($feature['counter']); ?></span>
                            <a href="<?php echo e($feature['route']); ?>"></a>
                            <img style="margin:auto; margin-bottom:1rem;" src="<?php echo e(asset($feature['icon'])); ?>">
                            <h5 class="f_600 t_color2"><?php echo e($feature['name']); ?></h5>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.subscriber.app', ['title' => @__('productHome.title')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/parvez/Desktop/product-lapse/resources/views/features/product/home.blade.php ENDPATH**/ ?>