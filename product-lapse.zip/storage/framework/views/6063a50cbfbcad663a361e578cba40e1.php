<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['color' => 'primary', 'hasIcon' => false]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['color' => 'primary', 'hasIcon' => false]); ?>
<?php foreach (array_filter((['color' => 'primary', 'hasIcon' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php
    $colorClass = match ($color) {
        'primary' => 'agency_banner_btn2',
        'secondary' => 'btn-bg-grey',
        'dark' => 'btn-bg3',
        'success' => 'btn-bg1',
        default => '',
    };
    $type = $attributes->has('type') ? $attributes->get('type') : 'submit';
    $action = $attributes->has('action') ? $attributes->get('action') : '';
    $class = $attributes->has('class') ? $attributes->has('class') : '';
    $enctype = $attributes->has('enctype') ? $attributes->has('enctype') : 'multipart/form-data';
?>

<?php switch(strtolower($type)):
    case ('submit'): ?>
        <button
            <?php echo e($attributes->merge(['class' => $hasIcon ? 'btn' : 'btn_hover agency_banner_btn btn-bg ' . $colorClass])); ?>><?php echo $slot ?? 'Button'; ?></button>
    <?php break; ?>

    <?php case ('button'): ?>
        <button
            <?php echo e($attributes->merge(['class' => $hasIcon ? 'btn' : 'btn_hover agency_banner_btn btn-bg ' . $colorClass])); ?>><?php echo $slot ?? 'Button'; ?></button>
    <?php break; ?>

    <?php case ('link'): ?>
        <a
            <?php echo e($attributes->merge(['class' => $hasIcon ? 'btn' : 'btn_hover agency_banner_btn btn-bg ' . $colorClass])); ?>><?php echo $slot ?? 'Link'; ?></a>
    <?php break; ?>

    <?php case ('delete'): ?>
        <form class="w-max h-max" action="<?php echo e($action); ?>" method="post" enctype="<?php echo e($enctype); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button class="<?php echo e($hasIcon ? 'btn' : 'btn_hover agency_banner_btn btn-bg ' . $colorClass . ' ' . $class); ?>"
                type="submit">
                <?php echo $slot ?? 'Form Submit'; ?>

            </button>
        </form>
    <?php break; ?>

    <?php default: ?>
        <button
            <?php echo e($attributes->merge(['class' => 'btn_hover agency_banner_btn btn-bg ' . $colorClass])); ?>><?php echo $slot ?? 'Button'; ?></button>
<?php endswitch; ?>
<?php /**PATH /home/parvez/Desktop/product-lapse/resources/views/components/button.blade.php ENDPATH**/ ?>