<div>
    <?php echo e($breadcrumb); ?>

    <section class="sign_in_area bg_color sec_pad">
        <div class="container">
            <div class="row">
                <?php echo e($details); ?>

                <?php echo e($profile); ?>

                 <div class="col-lg-8 blog_sidebar_left">
                    <div class="widget_title">
                        <h3 class=" f_size_20 t_color3"><?php echo __('comment.comments') ?></h3>
                        <div class="border_bottom"></div>
                    </div>
                    <?php echo e($comments); ?>

                    <div class="widget_title">
                        <h3 class=" f_size_20 t_color3"><?php echo __('comment.write-comment') ?></h3>
                        <div class="border_bottom"></div>
                    </div>
                    <?php echo e($writeComment); ?>

                </div>
               
            </div>
        </div>
    </section>
</div><?php /**PATH /home/parvez/Desktop/product-lapse/resources/views/components/feature/show.blade.php ENDPATH**/ ?>