<form method="get" action="<?php echo e($route); ?>">
    <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <input type="hidden" name="columns[]" value="<?php echo e($column); ?>">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <input type="hidden" name="model" value="<?php echo e($model); ?>">
    <?php if(isset($options)): ?>
        <select onchange="this.form.submit()" name="search" class="selectpickers selectpickers2">
            <option selected value=""><?php echo __('filter.all') ?></option>
            <?php $__empty_1 = true; $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <option <?php if(request()->query('search') == $opt->value->{app()->getLocale()}): echo 'selected'; endif; ?> value="<?= $opt->value->{app()->getLocale()} ?>">
                    <?= $opt->value->{app()->getLocale()} ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <option><?php echo __('filter.no-items') ?></option>
            <?php endif; ?>
        </select>
    <?php else: ?>
        <?php echo e($slot); ?>

    <?php endif; ?>

</form>
<?php /**PATH /home/parvez/Desktop/product-lapse/resources/views/components/filter.blade.php ENDPATH**/ ?>