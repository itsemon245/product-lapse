<?php $__env->startSection('main'); ?>
<?php if (isset($component)) { $__componentOriginal3bc35c24892c0136535a2452ecbc7bd5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3bc35c24892c0136535a2452ecbc7bd5 = $attributes; } ?>
<?php $component = App\View\Components\Feature\Index::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feature.index'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Feature\Index::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('breadcrumb', null, []); ?> 
        <?php if (isset($component)) { $__componentOriginal269900abaed345884ce342681cdc99f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal269900abaed345884ce342681cdc99f6 = $attributes; } ?>
<?php $component = App\View\Components\Breadcrumb::resolve(['list' => [['label' => @__('feature/invitation.title'), 'route' => route('invitation.index')]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Breadcrumb::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $attributes = $__attributesOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__attributesOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $component = $__componentOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__componentOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('search', null, []); ?> 
        <form action="#" class="search-form input-group">
            <input type="search" class="form-control widget_input" placeholder="<?php echo e(__('feature/invitation.search')); ?>">
            <button type="submit"><i class="ti-search"></i></button>
        </form>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('actions', null, []); ?> 
        <?php if (isset($component)) { $__componentOriginale67687e3e4e61f963b25a6bcf3983629 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale67687e3e4e61f963b25a6bcf3983629 = $attributes; } ?>
<?php $component = App\View\Components\Button::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'link','href' => ''.e(route('invitation.create')).'']); ?>
            <i class="ti-plus"></i>
            <?php echo __('feature/invitation.add') ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale67687e3e4e61f963b25a6bcf3983629)): ?>
<?php $attributes = $__attributesOriginale67687e3e4e61f963b25a6bcf3983629; ?>
<?php unset($__attributesOriginale67687e3e4e61f963b25a6bcf3983629); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale67687e3e4e61f963b25a6bcf3983629)): ?>
<?php $component = $__componentOriginale67687e3e4e61f963b25a6bcf3983629; ?>
<?php unset($__componentOriginale67687e3e4e61f963b25a6bcf3983629); ?>
<?php endif; ?>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('filter', null, []); ?> 
        
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('list', null, []); ?> 
        <?php $__currentLoopData = $invitations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invitation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-6">
            <div class="item lon new">
                <div class="list_item">
                    <div class="joblisting_text">
                        <div class="job_list_table">
                            <div class="jobsearch-table-cell">
                                <h4><a href="#" class="f_500 t_color3"><?php echo e($invitation->id); ?>-
                                        <?php echo e($invitation->first_name); ?> <?php echo e($invitation->last_name); ?></a>
                                </h4>
                                <ul class="list-unstyled">
                                    <li class="p_color4"><?php echo e($invitation->email); ?></li>
                                    <li class="p_color4"><?php echo e($invitation->phone); ?></li>
                                    <li class="p_color4"><?php echo e($invitation->position); ?></li>
                                    <li class="p_color4"><?php echo e($invitation->role); ?></li>
                                    <li class="p_color4">
                                        <?php echo e($invitation->accepted_at == null ? 'Not Accepted yet' : "Accepted at: " . $invitation->accepted_at); ?>

                                    </li>

                                </ul>
                            </div>
                            <div class="jobsearch-table-cell">
                                <div class="jobsearch-job-userlist">
                                    <div class="like-btn">
                                        <form
                                            action="<?php echo e(route('invitation.destroy', ['invitation' => base64_encode($invitation->id)])); ?>"
                                            method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>

                                            <button type="submit" class="shortlist" title="Delete">
                                                <i class="ti-trash"></i>
                                            </button>
                                        </form>

                                    </div>
                                    <div class="like-btn">
                                        <a href="<?php echo e(route('invitation.edit', ['invitation' => base64_encode($invitation->id)])); ?>"
                                            class="shortlist" title="Edit">
                                            <i class="ti-pencil"></i>
                                        </a>

                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3bc35c24892c0136535a2452ecbc7bd5)): ?>
<?php $attributes = $__attributesOriginal3bc35c24892c0136535a2452ecbc7bd5; ?>
<?php unset($__attributesOriginal3bc35c24892c0136535a2452ecbc7bd5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3bc35c24892c0136535a2452ecbc7bd5)): ?>
<?php $component = $__componentOriginal3bc35c24892c0136535a2452ecbc7bd5; ?>
<?php unset($__componentOriginal3bc35c24892c0136535a2452ecbc7bd5); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.subscriber.app', ['title' => @__('feature/invitation.title')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/parvez/Desktop/product-lapse/resources/views/features/product/invitation/index.blade.php ENDPATH**/ ?>