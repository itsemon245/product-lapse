<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['list' => []]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['list' => []]); ?>
<?php foreach (array_filter((['list' => []]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php if(count($list) > 0): ?>
<section class="breadcrumb_area">
    <div class="container d-flex">
        <div class="breadcrumb_content text-center ml-auto">
            <ul class="breadcrumb">
                <?php $__empty_1 = true; $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li class="breadcrumb-item <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?> "><a href="<?php echo e(route('dashboard')); ?>"><?php echo __('root.dashboard') ?></a></li>
                    <?php if($loop->last): ?>
                    <li class="breadcrumb-item active"><?php echo e($item['label']); ?></li>
                    <?php else: ?>
                    <li class="breadcrumb-item"><a href="<?php echo e($item['route']); ?>"><?php echo e($item['label']); ?></a></li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</section>
<?php endif; ?>
<?php /**PATH /home/parvez/Desktop/product-lapse/resources/views/components/breadcrumb.blade.php ENDPATH**/ ?>