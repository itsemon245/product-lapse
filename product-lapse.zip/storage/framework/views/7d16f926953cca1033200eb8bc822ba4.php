<ul class="dropdown-menu">
    <li class="nav-item"><a href="<?php echo e(route('profile.edit')); ?>" class="nav-link">Profile</a></li>
    <li class="nav-item"><a href="<?php echo e(route('invitation.index')); ?>" class="nav-link">Send Invitaion</a></li>
    <li class="nav-item"><a href="<?php echo e(route('dashboard')); ?>" class="nav-link">My Products</a></li>
    <li class="nav-item"><a href="#" class="nav-link">Reports</a></li>
    <li class="nav-item"><a href="<?php echo e(route('select.index')); ?>" class="nav-link">Select</a></li>
    <li class="nav-item"><a href="<?php echo e(route('certificate.index')); ?>" class="nav-link">Certificate</a></li>
    <li class="nav-item"><a href="#" class="nav-link">Settings</a></li>
    <form  action="<?php echo e(route('logout')); ?>" method="post">
        <?php echo csrf_field(); ?>
    <li class="nav-item" style="margin-top: 0px; margin-bottom: 0px;" >
        <button class="nav-link" >
            Logout
        </button>
    </li>
    </form>
</ul><?php /**PATH /home/parvez/Desktop/product-lapse/resources/views/layouts/global/profile-menu.blade.php ENDPATH**/ ?>