 <!-- Fonts -->
 <link rel="preconnect" href="https://fonts.bunny.net">
 <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />
 <script src="https://unpkg.com/htmx.org@1.9.6"
     integrity="sha384-FhXw7b6AlE/jyjlZH5iHa/tTe9EpJ1Y55RjcgPbjeWMskSxZt1v9qkxLJWNJaGni" crossorigin="anonymous">
 </script>

<?php echo notifyCss(); ?>
 <!-- Scripts -->
 <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
 <?php if(app()->getLocale() == 'ar'): ?>
     <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-reboot.min.css')); ?>">
 <?php endif; ?>

 <!-- Bootstrap CSS -->
 <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('vendors/bootstrap-selector/css/bootstrap-select.min.css')); ?>">
 <!--icon font css-->
 <link rel="stylesheet" href="<?php echo e(asset('vendors/themify-icon/themify-icons.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('vendors/elagent/style.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('vendors/flaticon/flaticon.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('vendors/animation/animate.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('vendors/owl-carousel/assets/owl.carousel.min.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('vendors/magnify-pop/magnific-popup.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('vendors/nice-select/nice-select.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('vendors/scroll/jquery.mCustomScrollbar.min.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('css/responsive.css')); ?>">

 <?php if(app()->getLocale() == 'ar'): ?>
     <link rel="stylesheet" href="<?php echo e(asset('css/rtl.css')); ?>">
 <?php endif; ?>
 <?php echo $__env->yieldPushContent('styles'); ?><?php /**PATH /home/parvez/Desktop/product-lapse/resources/views/layouts/global/styles.blade.php ENDPATH**/ ?>