<?php $__env->startSection('main'); ?>
    <?php if (isset($component)) { $__componentOriginala634755c2ab28b4e714796109735ef90 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala634755c2ab28b4e714796109735ef90 = $attributes; } ?>
<?php $component = App\View\Components\Feature\Show::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feature.show'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Feature\Show::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('breadcrumb', null, []); ?> 
            <?php if (isset($component)) { $__componentOriginal269900abaed345884ce342681cdc99f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal269900abaed345884ce342681cdc99f6 = $attributes; } ?>
<?php $component = App\View\Components\Breadcrumb::resolve(['list' => [['label' => @__('feature/product.info.title'), 'route' => route('product.info')]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Breadcrumb::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $attributes = $__attributesOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__attributesOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $component = $__componentOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__componentOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
         <?php $__env->endSlot(); ?>


         <?php $__env->slot('details', null, []); ?> 
            
            <div class="col-lg-6 blog_sidebar_left">
                <div class="blog_single mb_50">
                    <div class="">
                        <h5 class="f_size_20 f_500"><?php echo e($product->name); ?></h5>
                        <div class="entry_post_info">
                            <?php echo e(\Carbon\Carbon::parse($product->created_at)->format('l, j F Y')); ?>

                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <h6 class="title2"><?php echo __('feature/product.info.category') ?></h6>
                                <p class="f_400 mb-30 text-font">
                                    <?php echo e($product->category); ?>

                                </p>
                            </div>
                            <div class="col-md-6">
                                <h6 class="title2"><?php echo __('feature/product.info.stage') ?></h6>
                                <p class="f_400 mb-30 text-font">
                                    <?php echo e($product->stage); ?>

                                </p>
                            </div>
                        </div>
                        <h6 class="title2"><?php echo __('feature/product.info.description') ?></h6>
                        <p class="f_400 mb-30 text-font">
                            <?php echo e($product->description); ?>

                        </p>
                    </div>
                </div>

            </div>
         <?php $__env->endSlot(); ?>
         <?php $__env->slot('profile', null, []); ?> 
            <div class="col-lg-3">
                <div class="blog-sidebar box-sidebar">
                    <div class="widget sidebar_widget widget_recent_post mt_60">
                        <div class="media post_author mt_60">
                            <img class="rounded-circle" src="<?php echo e($owner->image == null ? asset('img/p2.jpg') : $owner->image->url); ?>" alt="">
                            <div class="media-body">
                                <h5 class=" t_color3 f_size_18 f_500"><?php echo e($owner->name); ?></h5>
                            </div>
                        </div>
                        <h6 class="title2"><?php echo __('feature/product.info.created') ?>: <span class="f_400 mb-30 text-font"><?php echo e($owner->name); ?></span></h6>
                    </div>

                </div>

            </div>
            <div class="col-lg-3">
                <div class="mt-5 pt-2">
                    <img src="<?php echo e($product->image?->url); ?>" alt="">
                </div>

            </div>
         <?php $__env->endSlot(); ?>
         <?php $__env->slot('comments', null, []); ?> 
            <ul class="comment-box list-unstyled mb-0">
                <li class="post_comment">
                    <div class="media post_author mt_60">
                        <div class="media-left">
                            <img class="rounded-circle" src="img/profile1.png" alt="">
                            <a href="#" class="replay"><i class="ti-share"></i></a>
                        </div>
                        <div class="media-body">
                            <h5 class=" t_color3 f_size_18 f_500">Mohamed Ali</h5>
                            <h6 class=" f_size_15 f_400 mb_20">24 March 2023</h6>
                            <p>It is a long established fact that a reader will be distracted by the readable content of a
                                page when looking at its layout</p>
                        </div>
                    </div>
                    <ul class="reply-comment list-unstyled">
                        <li class="post-comment">
                            <div class="media post_author comment-content">
                                <div class="media-left">
                                    <img class="rounded-circle" src="img/profile2.png" alt="">
                                    <a href="#" class="replay"><i class="ti-share"></i></a>
                                </div>
                                <div class="media-body">
                                    <h5 class=" t_color3 f_size_18 f_500">Mohamed Ali</h5>
                                    <h6 class=" f_size_15 f_400 mb_20">24 March 2023</h6>
                                    <p>It is a long established fact that a reader will be distracted by the readable
                                        content of a page when looking at its layout</p>
                                </div>
                            </div>
                        </li>
                    </ul>
                </li>
            </ul>
         <?php $__env->endSlot(); ?>
         <?php $__env->slot('writeComment', null, []); ?> 
            <form class="get_quote_form row" action="#" method="post">
                <div class="col-md-12 form-group">
                    <textarea class="form-control message" placeholder="Write your comment here .."></textarea>
                </div>
                <div class="col-md-12"><button class="btn_hover agency_banner_btn btn-bg" type="submit">Send</button></div>
            </form>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala634755c2ab28b4e714796109735ef90)): ?>
<?php $attributes = $__attributesOriginala634755c2ab28b4e714796109735ef90; ?>
<?php unset($__attributesOriginala634755c2ab28b4e714796109735ef90); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala634755c2ab28b4e714796109735ef90)): ?>
<?php $component = $__componentOriginala634755c2ab28b4e714796109735ef90; ?>
<?php unset($__componentOriginala634755c2ab28b4e714796109735ef90); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.subscriber.app', ['title' => @__('feature/product.info.title')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/parvez/Desktop/product-lapse/resources/views/features/product/partials/show.blade.php ENDPATH**/ ?>