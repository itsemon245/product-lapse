<?php $__env->startSection('main'); ?>
    <?php if (isset($component)) { $__componentOriginal3bc35c24892c0136535a2452ecbc7bd5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3bc35c24892c0136535a2452ecbc7bd5 = $attributes; } ?>
<?php $component = App\View\Components\Feature\Index::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feature.index'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Feature\Index::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('breadcrumb', null, []); ?> 
            <?php if (isset($component)) { $__componentOriginal269900abaed345884ce342681cdc99f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal269900abaed345884ce342681cdc99f6 = $attributes; } ?>
<?php $component = App\View\Components\Breadcrumb::resolve(['list' => [['label' => @__('feature/report.title'), 'route' => route('report.index')]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Breadcrumb::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $attributes = $__attributesOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__attributesOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $component = $__componentOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__componentOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
         <?php $__env->endSlot(); ?>

     <?php $__env->slot('search', null, []); ?> 
    <form method="GET" hx-get="<?php echo e(route('report.search')); ?>" hx-trigger="submit" hx-target="#search-results" hx-select="#search-results" class="search-form input-group">
        <input type="hidden" name="columns[]" value="name">
        <input type="hidden" name="columns[]" value="type">
        <input type="hidden" name="model" value="report">
        <input type="search" name="search" class="form-control widget_input" placeholder="<?php echo e(__('feature/report.search')); ?>" hx-vals="#search-results">
        <button type="submit"><i class="ti-search"></i></button>
    </form>
     <?php $__env->endSlot(); ?>


         <?php $__env->slot('actions', null, []); ?> 
            <?php if (isset($component)) { $__componentOriginale67687e3e4e61f963b25a6bcf3983629 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale67687e3e4e61f963b25a6bcf3983629 = $attributes; } ?>
<?php $component = App\View\Components\Button::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'link','href' => ''.e(route('report.create')).'']); ?>
                <i class="ti-plus"></i>
                <?php echo __('feature/report.add') ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale67687e3e4e61f963b25a6bcf3983629)): ?>
<?php $attributes = $__attributesOriginale67687e3e4e61f963b25a6bcf3983629; ?>
<?php unset($__attributesOriginale67687e3e4e61f963b25a6bcf3983629); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale67687e3e4e61f963b25a6bcf3983629)): ?>
<?php $component = $__componentOriginale67687e3e4e61f963b25a6bcf3983629; ?>
<?php unset($__componentOriginale67687e3e4e61f963b25a6bcf3983629); ?>
<?php endif; ?>
         <?php $__env->endSlot(); ?>

         <?php $__env->slot('filter', null, []); ?> 
            <h5><?php echo __('feature/report.showing') ?></h5>
            <?php if (isset($component)) { $__componentOriginalb68d555c13273f9d26aedfa8ff6c880d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb68d555c13273f9d26aedfa8ff6c880d = $attributes; } ?>
<?php $component = App\View\Components\Filter::resolve(['route' => route('report.search'),'columns' => ['type'],'model' => 'report','options' => $types] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('filter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Filter::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb68d555c13273f9d26aedfa8ff6c880d)): ?>
<?php $attributes = $__attributesOriginalb68d555c13273f9d26aedfa8ff6c880d; ?>
<?php unset($__attributesOriginalb68d555c13273f9d26aedfa8ff6c880d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb68d555c13273f9d26aedfa8ff6c880d)): ?>
<?php $component = $__componentOriginalb68d555c13273f9d26aedfa8ff6c880d; ?>
<?php unset($__componentOriginalb68d555c13273f9d26aedfa8ff6c880d); ?>
<?php endif; ?>
         <?php $__env->endSlot(); ?>


     <?php $__env->slot('list', null, []); ?> 
        <?php $__empty_1 = true; $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-md-6">
            <div class="item lon new">
                <div class="list_item">
                    <figure><a href="<?php echo e(route('report.show', $report)); ?>"><img src="img/p1.jpg" alt=""></a></figure>
                    <div class="joblisting_text">
                        <div class="job_list_table">
                            <div class="jobsearch-table-cell">
                                <h4><a href="#" class="f_500 t_color3"><?php echo e($report->name); ?></a></h4>
                                <ul class="list-unstyled">
                                    <li>
                                        <?php echo e($report->type); ?>

                                    </li>
                                    <li class="text-muted"><?php echo e($report->created_at->formatLocalized('%A %d %B %Y')); ?></li>
                                </ul>
                            </div>
                            <div class="jobsearch-table-cell">
                                <div class="jobsearch-job-userlist">
                                    <div class="like-btn">
                                        <?php if (isset($component)) { $__componentOriginal660c4ad06be89181a24a71008ee12010 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal660c4ad06be89181a24a71008ee12010 = $attributes; } ?>
<?php $component = App\View\Components\BtnIcons::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('btn-icons'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\BtnIcons::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','class' => 'btn','value' => '<i class=\'ti-more\'></i>']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal660c4ad06be89181a24a71008ee12010)): ?>
<?php $attributes = $__attributesOriginal660c4ad06be89181a24a71008ee12010; ?>
<?php unset($__attributesOriginal660c4ad06be89181a24a71008ee12010); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal660c4ad06be89181a24a71008ee12010)): ?>
<?php $component = $__componentOriginal660c4ad06be89181a24a71008ee12010; ?>
<?php unset($__componentOriginal660c4ad06be89181a24a71008ee12010); ?>
<?php endif; ?>
                                    </div>
                                    <div class="jobsearch-table-cell">
                                        <div class="jobsearch-job-userlist">
                                            <div class="like-btn">
                                                <form action="<?php echo e(route('report.destroy', $report)); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <?php if (isset($component)) { $__componentOriginal660c4ad06be89181a24a71008ee12010 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal660c4ad06be89181a24a71008ee12010 = $attributes; } ?>
<?php $component = App\View\Components\BtnIcons::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('btn-icons'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\BtnIcons::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','class' => 'btn','value' => '<i class=\'ti-trash\'></i>']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal660c4ad06be89181a24a71008ee12010)): ?>
<?php $attributes = $__attributesOriginal660c4ad06be89181a24a71008ee12010; ?>
<?php unset($__attributesOriginal660c4ad06be89181a24a71008ee12010); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal660c4ad06be89181a24a71008ee12010)): ?>
<?php $component = $__componentOriginal660c4ad06be89181a24a71008ee12010; ?>
<?php unset($__componentOriginal660c4ad06be89181a24a71008ee12010); ?>
<?php endif; ?>
                                                </form>
                                            </div>
                                            <div class="like-btn">
                                                <?php if (isset($component)) { $__componentOriginal660c4ad06be89181a24a71008ee12010 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal660c4ad06be89181a24a71008ee12010 = $attributes; } ?>
<?php $component = App\View\Components\BtnIcons::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('btn-icons'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\BtnIcons::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'anchor','value' => '<i class=\'ti-pencil\'></i>','href' => ''.e(route('report.edit', $report)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal660c4ad06be89181a24a71008ee12010)): ?>
<?php $attributes = $__attributesOriginal660c4ad06be89181a24a71008ee12010; ?>
<?php unset($__attributesOriginal660c4ad06be89181a24a71008ee12010); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal660c4ad06be89181a24a71008ee12010)): ?>
<?php $component = $__componentOriginal660c4ad06be89181a24a71008ee12010; ?>
<?php unset($__componentOriginal660c4ad06be89181a24a71008ee12010); ?>
<?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> 
        <?php if (isset($component)) { $__componentOriginal02093281cfa0ca4250dd4a03f892fa0e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal02093281cfa0ca4250dd4a03f892fa0e = $attributes; } ?>
<?php $component = App\View\Components\Feature\NotFound::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feature.not-found'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Feature\NotFound::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal02093281cfa0ca4250dd4a03f892fa0e)): ?>
<?php $attributes = $__attributesOriginal02093281cfa0ca4250dd4a03f892fa0e; ?>
<?php unset($__attributesOriginal02093281cfa0ca4250dd4a03f892fa0e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal02093281cfa0ca4250dd4a03f892fa0e)): ?>
<?php $component = $__componentOriginal02093281cfa0ca4250dd4a03f892fa0e; ?>
<?php unset($__componentOriginal02093281cfa0ca4250dd4a03f892fa0e); ?>
<?php endif; ?> 
        <?php endif; ?>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3bc35c24892c0136535a2452ecbc7bd5)): ?>
<?php $attributes = $__attributesOriginal3bc35c24892c0136535a2452ecbc7bd5; ?>
<?php unset($__attributesOriginal3bc35c24892c0136535a2452ecbc7bd5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3bc35c24892c0136535a2452ecbc7bd5)): ?>
<?php $component = $__componentOriginal3bc35c24892c0136535a2452ecbc7bd5; ?>
<?php unset($__componentOriginal3bc35c24892c0136535a2452ecbc7bd5); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?> 

<?php echo $__env->make('layouts.subscriber.app', ['title' => @__('feature/report.title')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/parvez/Desktop/product-lapse/resources/views/features/report/index.blade.php ENDPATH**/ ?>