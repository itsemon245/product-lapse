<?php
    $id = $attributes->has('id') ? $attributes->get('id') : 'Primary';
    $extra = $attributes->has('value') ? $attributes->get('value') : '';
    $name = $attributes->has('name') ? $attributes->get('name') : '';
    $route = $attributes->has('href') ? $attributes->get('href') : '';
    $class = $attributes->has('class') ? $attributes->get('class') : '';
    $type = $attributes->get('type');
?>


<?php if($type == 'anchor'): ?>
<a <?php echo e($attributes->merge([ 'class' => $class , 'href' => $route ])->merge(['id' => $id ])); ?>> <?php echo $extra; ?> <?php echo e($name); ?></a>
<?php else: ?>
<button <?php echo e($attributes->merge([ 'class' => $class, 'type' => $type ])->merge(['id' => $id ])); ?>> <?php echo $extra; ?> <?php echo e($name); ?></button>
<?php endif; ?>


<?php $__env->startPush('customJs'); ?>
    <script>
        $(document).ready(function() {
            btn = $('#<?php echo e($id); ?>')
            btn.click(e => {
                history.back()
            })
        });
    </script>
<?php $__env->stopPush(); ?><?php /**PATH /home/parvez/Desktop/product-lapse/resources/views/components/btn-icons.blade.php ENDPATH**/ ?>