<?php $__env->startSection('main'); ?>
    <?php if (isset($component)) { $__componentOriginal3bc35c24892c0136535a2452ecbc7bd5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3bc35c24892c0136535a2452ecbc7bd5 = $attributes; } ?>
<?php $component = App\View\Components\Feature\Index::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feature.index'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Feature\Index::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('breadcrumb', null, []); ?> 
            <?php if (isset($component)) { $__componentOriginal269900abaed345884ce342681cdc99f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal269900abaed345884ce342681cdc99f6 = $attributes; } ?>
<?php $component = App\View\Components\Breadcrumb::resolve(['list' => [['label' => @__('feature/delivery.title'), 'route' => route('delivery.index')]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Breadcrumb::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $attributes = $__attributesOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__attributesOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $component = $__componentOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__componentOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
         <?php $__env->endSlot(); ?>

         <?php $__env->slot('search', null, []); ?> 
            <form method="GET" hx-get="<?php echo e(route('delivery.search')); ?>" hx-trigger="submit" hx-target="#search-results"
                hx-select="#search-results" class="search-form input-group">
                <input type="hidden" name="columns[]" value="name">
                <input type="hidden" name="columns[]" value="items">
                <input type="hidden" name="model" value="delivery">
                <input type="search" name="search" class="form-control widget_input"
                    placeholder="<?php echo e(__('feature/delivery.search')); ?>" hx-vals="#search-results">
                <button type="submit"><i class="ti-search"></i></button>
            </form>
         <?php $__env->endSlot(); ?>

         <?php $__env->slot('actions', null, []); ?> 
            <?php if (isset($component)) { $__componentOriginale67687e3e4e61f963b25a6bcf3983629 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale67687e3e4e61f963b25a6bcf3983629 = $attributes; } ?>
<?php $component = App\View\Components\Button::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'link','href' => ''.e(route('delivery.create')).'']); ?>
            <x-button type="submit" action=<?php echo e(route('delivery.create')); ?>>
                <i class="ti-plus"></i>
                <?php echo __('feature/delivery.add') ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale67687e3e4e61f963b25a6bcf3983629)): ?>
<?php $attributes = $__attributesOriginale67687e3e4e61f963b25a6bcf3983629; ?>
<?php unset($__attributesOriginale67687e3e4e61f963b25a6bcf3983629); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale67687e3e4e61f963b25a6bcf3983629)): ?>
<?php $component = $__componentOriginale67687e3e4e61f963b25a6bcf3983629; ?>
<?php unset($__componentOriginale67687e3e4e61f963b25a6bcf3983629); ?>
<?php endif; ?>
         <?php $__env->endSlot(); ?>

         <?php $__env->slot('filter', null, []); ?> 
            
         <?php $__env->endSlot(); ?>

         <?php $__env->slot('list', null, []); ?> 
            <?php $__empty_1 = true; $__currentLoopData = $deliveries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delivery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-md-6">
                <div class="item lon new">
                    <div class="list_item">
                        <div class="joblisting_text document-list">
                            <div class="job_list_table">
                                <div class="jobsearch-table-cell">
                                    <h4><a href="<?php echo e(route('delivery.show', base64_encode($delivery->id))); ?>"
                                            class="f_500 t_color3"><?php echo e($delivery->name); ?></a></h4>
                                    <ul class="list-unstyled">
                                        <li>
                                            <?php echo e(\Carbon\Carbon::parse($delivery->required_completion_date)->format('l, j F Y')); ?>

                                        </li>
                                    </ul>
                                </div>
                                <div class="jobsearch-table-cell">
                                    <div class="jobsearch-job-userlist">
                                        <div class="like-btn">
                                            <form action="<?php echo e(route('delivery.destroy', base64_encode($delivery->id))); ?>"
                                                method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <?php if (isset($component)) { $__componentOriginal660c4ad06be89181a24a71008ee12010 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal660c4ad06be89181a24a71008ee12010 = $attributes; } ?>
<?php $component = App\View\Components\BtnIcons::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('btn-icons'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\BtnIcons::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','class' => 'btn','value' => '<i class=\'ti-trash\'></i>']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal660c4ad06be89181a24a71008ee12010)): ?>
<?php $attributes = $__attributesOriginal660c4ad06be89181a24a71008ee12010; ?>
<?php unset($__attributesOriginal660c4ad06be89181a24a71008ee12010); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal660c4ad06be89181a24a71008ee12010)): ?>
<?php $component = $__componentOriginal660c4ad06be89181a24a71008ee12010; ?>
<?php unset($__componentOriginal660c4ad06be89181a24a71008ee12010); ?>
<?php endif; ?>
                                            </form>
                                        </div>
                                        <div class="like-btn">
                                            <?php if (isset($component)) { $__componentOriginal660c4ad06be89181a24a71008ee12010 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal660c4ad06be89181a24a71008ee12010 = $attributes; } ?>
<?php $component = App\View\Components\BtnIcons::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('btn-icons'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\BtnIcons::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'anchor','value' => '<i class=\'ti-pencil\'></i>','href' => ''.e(route('delivery.edit', base64_encode($delivery->id))).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal660c4ad06be89181a24a71008ee12010)): ?>
<?php $attributes = $__attributesOriginal660c4ad06be89181a24a71008ee12010; ?>
<?php unset($__attributesOriginal660c4ad06be89181a24a71008ee12010); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal660c4ad06be89181a24a71008ee12010)): ?>
<?php $component = $__componentOriginal660c4ad06be89181a24a71008ee12010; ?>
<?php unset($__componentOriginal660c4ad06be89181a24a71008ee12010); ?>
<?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php if (isset($component)) { $__componentOriginal02093281cfa0ca4250dd4a03f892fa0e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal02093281cfa0ca4250dd4a03f892fa0e = $attributes; } ?>
<?php $component = App\View\Components\Feature\NotFound::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feature.not-found'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Feature\NotFound::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal02093281cfa0ca4250dd4a03f892fa0e)): ?>
<?php $attributes = $__attributesOriginal02093281cfa0ca4250dd4a03f892fa0e; ?>
<?php unset($__attributesOriginal02093281cfa0ca4250dd4a03f892fa0e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal02093281cfa0ca4250dd4a03f892fa0e)): ?>
<?php $component = $__componentOriginal02093281cfa0ca4250dd4a03f892fa0e; ?>
<?php unset($__componentOriginal02093281cfa0ca4250dd4a03f892fa0e); ?>
<?php endif; ?>
            <?php endif; ?>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3bc35c24892c0136535a2452ecbc7bd5)): ?>
<?php $attributes = $__attributesOriginal3bc35c24892c0136535a2452ecbc7bd5; ?>
<?php unset($__attributesOriginal3bc35c24892c0136535a2452ecbc7bd5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3bc35c24892c0136535a2452ecbc7bd5)): ?>
<?php $component = $__componentOriginal3bc35c24892c0136535a2452ecbc7bd5; ?>
<?php unset($__componentOriginal3bc35c24892c0136535a2452ecbc7bd5); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.subscriber.app', ['title' => @__('feature/delivery.title')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/parvez/Desktop/product-lapse/resources/views/features/delivery/index.blade.php ENDPATH**/ ?>