<?php $__env->startSection('main'); ?>
    <section class="breadcrumb_area">
        <div class="container">
            <div class="breadcrumb_content text-center">
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><?php echo app('translator')->get('login.home'); ?></a></li>
                    <li class="breadcrumb-item active"><?php echo app('translator')->get('login.login'); ?></li>
                </ul>
            </div>
        </div>
    </section>
    <section class="sign_in_area bg_color sec_pad">
        <div class="container">
            <div class="sign_info">
                <div class="row">
                    <div class="col-lg-7">
                        <?php if(session('success')): ?>
                            <div class="bg-green-500 text-white p-4 mb-4">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>
                        <div class="login_info">
                            <h2 class=" f_600 f_size_24 t_color3 mb_40"><?php echo app('translator')->get('login.login'); ?></h2>
                            <form action="<?php echo e(route('login')); ?>" method="POST" enctype="multipart/form-data"
                                class="login-form sign-in-form"><?php echo csrf_field(); ?>
                                <div class="form-group text_box">
                                    <label class=" text_c f_500"><?php echo app('translator')->get('login.email'); ?></label>
                                    <input type="text" placeholder="enter email" name="email">
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group text_box">
                                    <label class=" text_c f_500"><?php echo app('translator')->get('login.password'); ?></label>
                                    <input type="password" name="password">
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="extra mb_20">
                                    <div class="checkbox remember">
                                        <label>
                                            <input type="checkbox"> <?php echo app('translator')->get('login.save'); ?>
                                        </label>
                                    </div>
                                    <!--//check-box-->
                                    <div class="forgotten-password">
                                        <a href="#"><?php echo app('translator')->get('login.forgot_password'); ?></a>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-between align-items-center">
                                    <button type="submit"
                                        class="btn_hover agency_banner_btn btn-bg"><?php echo app('translator')->get('login.login'); ?></button>
                                    <div class="social_text d-flex ">
                                        <div class="lead-text"><?php echo app('translator')->get('login.login_within'); ?></div>
                                        <ul class="list-unstyled social_tag mb-0">
                                            <li><a href="#"><i class="ti-linkedin"></i></a></li>
                                            <li><a href="#"><i class="ti-google"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="col-lg-5">
                        <div class="sign_info_content">
                            <h3 class=" f_600 f_size_24 t_color3 mb_40"><?php echo app('translator')->get('login.dont_have_account'); ?></h3>
                            <h2 class=" f_400 f_size_30 mb-30"><?php echo app('translator')->get('login.join'); ?></h2>
                            <ul class="list-unstyled mb-0">
                                <li><i class="ti-check"></i><?php echo app('translator')->get('login.product_vision'); ?></li>
                                <li><i class="ti-check"></i><?php echo app('translator')->get('login.product_planning'); ?></li>
                                <li><i class="ti-check"></i><?php echo app('translator')->get('login.product_support'); ?></li>
                                <li><i class="ti-check"></i><?php echo app('translator')->get('login.team_collaboration'); ?></li>
                                <li><i class="ti-check"></i><?php echo app('translator')->get('login.many_features'); ?></li>
                            </ul>
                            <a href="<?php echo e(route('register')); ?>" class="btn_three sign_btn_transparent"><?php echo app('translator')->get('login.sign_up'); ?></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/parvez/Desktop/product-lapse/resources/views/auth/login.blade.php ENDPATH**/ ?>