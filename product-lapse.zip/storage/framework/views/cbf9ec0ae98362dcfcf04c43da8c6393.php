<div class="m-0 p-0">
    <?php echo e($breadcrumb); ?>

    <section class="sign_in_area bg_color sec_pad">
        <div class="container">
            <div class="sign_info">
                <div class="login_info">
                    <?php echo e($from); ?>

                </div>
            </div>
        </div>
    </section>
</div>
<?php /**PATH /home/parvez/Desktop/product-lapse/resources/views/components/feature/edit.blade.php ENDPATH**/ ?>